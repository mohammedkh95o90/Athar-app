// Smoke tests for Athar. Uses only Node.js built-ins; no real API keys are required.
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const path = require('node:path');
const port = 20000 + Math.floor(Math.random() * 30000);
const base = `http://127.0.0.1:${port}`;
const child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
  env: { ...process.env, PORT: String(port), OPENAI_API_KEY: '', SUPABASE_URL: '', SUPABASE_ANON_KEY: '' },
  stdio: ['ignore', 'pipe', 'pipe']
});
let logs = '';
child.stdout.on('data', x => logs += x.toString());
child.stderr.on('data', x => logs += x.toString());
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function waitForServer() {
  for (let i = 0; i < 60; i++) {
    if (child.exitCode !== null) throw new Error(`Server exited early: ${logs}`);
    try { const r = await fetch(`${base}/api/health`); if (r.ok) return; } catch {}
    await sleep(150);
  }
  throw new Error(`Server did not start: ${logs}`);
}
(async () => {
  try {
    await waitForServer();
    let r = await fetch(`${base}/api/health`);
    let j = await r.json();
    assert.equal(r.status, 200); assert.equal(j.ok, true); assert.equal(j.aiConfigured, false);
    console.log('PASS health endpoint reports server alive and AI unconfigured');

    r = await fetch(base);
    const html = await r.text();
    assert.equal(r.status, 200); assert.match(html, /أَثَر/); assert.match(html, /الرسائل الخاصة/); assert.match(html, /اسأل أَثَر/);
    console.log('PASS home page serves the Athar UI with private messages and AI entry points');

    r = await fetch(`${base}/.env.example`);
    assert.equal(r.status, 404);
    console.log('PASS hidden environment files are not served');

    r = await fetch(`${base}/api/ask`, { method: 'POST', headers: {'content-type':'application/json'}, body: JSON.stringify({question:'اختبار'}) });
    j = await r.json();
    assert.equal(r.status, 503); assert.match(j.error, /لم يُفعّل/);
    console.log('PASS AI endpoint fails closed when no secret API key is configured');

    r = await fetch(`${base}/missing-page`);
    assert.equal(r.status, 404);
    console.log('PASS unknown paths return 404');
    console.log('\nAll local smoke tests passed. External Supabase/OpenAI integrations are not tested by this script.');
  } catch (e) {
    console.error('FAIL', e); process.exitCode = 1;
  } finally {
    child.kill('SIGTERM');
  }
})();
