// خادم اختياري لتشغيل واجهة أَثَر محليًا. مجتمع المنشورات المشترك يتصل مباشرة بـ Supabase.
const http = require('http');
const fs = require('fs');
const path = require('path');
const ROOT = __dirname;
const PORT = Number(process.env.PORT || 8787);
const MIME = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.webmanifest':'application/manifest+json','.json':'application/json','.txt':'text/plain; charset=utf-8','.sql':'text/plain; charset=utf-8'};
http.createServer((req,res)=>{
  const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  let pathname = decodeURIComponent(u.pathname === '/' ? '/index.html' : u.pathname);
  if (pathname.includes('..') || pathname.startsWith('/.')) { res.writeHead(404); return res.end('Not found'); }
  const file = path.join(ROOT, pathname);
  fs.readFile(file,(err,data)=>{
    if(err){res.writeHead(404,{'content-type':'text/plain; charset=utf-8'});return res.end('الملف غير موجود');}
    res.writeHead(200,{'content-type':MIME[path.extname(file)]||'application/octet-stream','x-content-type-options':'nosniff','cache-control':path.basename(file)==='index.html'?'no-cache':'public, max-age=3600'});res.end(data);
  });
}).listen(PORT,()=>console.log(`Athar web app: http://localhost:${PORT}`));
